const mongoose = require("mongoose");

// Creating the schema for seller requests
const request_sellerSchema = new mongoose.Schema(
    {
        name: {
            type: String, // FIX: A name should be a String, not a Number.
            required: true,
        },
        product: {
            type: String,
            required: true,
        },
        quantity: {
            type: Number,
            required: true,
        },
        price: { // ADDED: Price per unit (e.g., price per kg) to calculate total.
            type: Number,
            required: true,
        },
       
        location: {
            type: String,
            required: true,
        },
        status: { // ADDED: To match the "PENDING" status in your design.
            type: String,
            required: true,
            default: 'PENDING'
        },
        deliveryBy: { // ADDED: A specific field for the delivery date from your design.
            type: Date,
            required: true
        }
        // NOTE: We don't need a manual createdAt field because of {timestamps: true} below.
        // It will be added automatically.
    },
    { timestamps: true } // This automatically adds createdAt and updatedAt fields.
);

module.exports = mongoose.model("RequestBySeller", request_sellerSchema); // Changed model name to standard practice