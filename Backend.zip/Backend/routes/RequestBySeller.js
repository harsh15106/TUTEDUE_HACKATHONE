const router = require("express").Router();
const request = require("../database/request_by_seller"); // Ensure this path is correct

/**
 * @desc   Create a new request
 * @route  POST /api/v1/requests
 */
// FIX: The full path '/requests' is now defined here.
// This makes the router compatible with an app.js setup like: app.use('/api/v1', requestRoutes);
router.post('/requests', async (req, res) => {
    try {
        const { name, product, quantity, price, type, location, status, deliveryBy } = req.body;
        console.log('POST /api/v1/requests - Creating new request:', req.body);

        if (!name || !product || quantity === undefined || price === undefined || !deliveryBy) {
            return res.status(400).json({ 
                message: 'Missing required fields: name, product, quantity, price, and deliveryBy are required.' 
            });
        }

        const newRequest = new Request({
            name, product, quantity, price, type, location, status, deliveryBy,
        });

        const savedRequest = await newRequest.save();
        res.status(201).json({
            message: "Request item added successfully",
            data: savedRequest
        });

    } catch (error) {
        console.error("Server error while adding request:", error);
        res.status(500).json({ message: "Server error while adding request.", error: error.message });
    }
});

/**
 * @desc   Delete a request by its ID
 * @route  DELETE /api/v1/requests/:id
 */
// FIX: The full path '/requests/:id' is now defined here.
router.delete('/requests/:id', async (req, res) => {
    try {
        const requestId = req.params.id;
        console.log(`DELETE /api/v1/requests/${requestId} - Deleting request`);

        const deletedRequest = await Request.findByIdAndDelete(requestId);

        if (!deletedRequest) {
            return res.status(404).json({ message: `Request item with ID ${requestId} not found.` });
        }
        
        res.status(200).json({ message:` Request item with ID ${requestId} deleted successfully. `});

    } catch (error) { 
        console.error("Server error while deleting request:", error);
        res.status(500).json({ message: "Server error while deleting request.", error: error.message });
    }
});

// You would also add your GET and PATCH routes here following the same pattern
// For example: router.get('/requests', getAllRequests);
// For example: router.patch('/requests/:id', updateRequestStatus);

module.exports = router;